/* ------------------------------ TASK 3 -----------------------------------
Parašykite JS kodą, kuris leis vartotojui paspaudus ant mygtuko "Show users"
pamatyti vartotojus iš Github API (endpoint'as pateiktas žemiau).

Paspaudus mygtuką "Show users":
1. Pateikiamas informacijos atvaizdavimas <div id="output"></div> bloke
1.1. Infrmacija, kuri pateikiama: "login" ir "avatar_url" reikšmės (kortelėje)
2. Žinutė "Press "Show Users" button to see users" turi išnykti;
"
Pastaba: Informacija apie user'į (jo kortelė) bei turi turėti bent minimalų stilių;
-------------------------------------------------------------------------- */

const ENDPOINT = "https://api.github.com/users";

const buttonShowUsers = document.getElementById("btn");
const message = document.getElementById("message");
const output = document.getElementById("output");

buttonShowUsers.addEventListener("click", (event) => {
  event.preventDefault();
  output.innerHTML = "";
  fetch(ENDPOINT)
    .then((response) => response.json())
    .then((data) => {
      const table = createUsersTable(data);
      output.appendChild(table);
    });
});

function createUsersTable(users) {
  const table = document.createElement("table");

  const thead = document.createElement("thead");
  table.appendChild(thead);

  const theadRow = createRow();
  thead.appendChild(theadRow);

  const th1 = createTh("User name");
  theadRow.appendChild(th1);

  const th2 = createTh("URL");
  theadRow.appendChild(th2);

  const tbody = document.createElement("tbody");
  table.appendChild(tbody);

  users.forEach((user) => {
    const tr = createRow();
    tr.append(createTd(user.login), createTd(user.avatar_url));
    tbody.appendChild(tr);
  });
  table.style.background = "#76872b";
  table.style.borderCollapse = "collapse";
  table.style.minWidth = "90%";
  table.style.margin = "0 auto";
  return table;
}

let createRow = () => document.createElement("tr");

function createTd(textContent) {
  const td = document.createElement("td");
  td.textContent = textContent;
  td.style.border = "1px solid black";
  td.style.padding = "5px";
  return td;
}

function createTh(textContent) {
  const td = document.createElement("th");
  td.textContent = textContent;
  td.style.border = "2px solid black";
  td.style.padding = "5px";
  return td;
}
