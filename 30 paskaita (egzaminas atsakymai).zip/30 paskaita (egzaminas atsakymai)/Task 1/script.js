/* ------------------------------ TASK 1 ----------------------------
Parašykite JS kodą, kuris leis vartotojui įvesti svorį kilogramais ir
pamatyti jo pateikto svorio kovertavimą į:
1. Svarus (lb) | Formulė: lb = kg * 2.2046
2. Gramus (g) | Formulė: g = kg / 0.0010000
3. Uncijos (oz) | Formul4: oz = kg * 35.274

Pastaba: atvaizdavimas turi būti matomas pateikus formą ir pateikiamas
<div id="output"></div> viduje, bei turi turėti bent minimalų stilių;
------------------------------------------------------------------- */

const output = document.getElementById("output");
const inputField = document.getElementById("search");
const submitButton = document.getElementById("submit-btn");

submitButton.addEventListener("click", (event) => {
      event.preventDefault();
      printAnswer();
});

function printAnswer() {
    const inputValue = Number(inputField.value);
     
    output.style.margin = "0 auto";
    output.style.maxWidth = "80%";
    output.style.backgroundColor = "#186b2e";
    output.style.padding = "20px";
    output.style.border = "1px solid black";
    output.style.textAlign = "left";
    output.style.fontSize = "2.5em";
    output.style.whiteSpace = "pre";

    output.textContent = inputValue + " kg = " + (inputValue * 2.2046).toFixed(0) + "lb\r\n";
    output.textContent += inputValue + " kg = " + (inputValue / 0.001000).toFixed(0) + "g\r\n";
    output.textContent += inputValue + " kg = " + (inputValue * 35.274).toFixed(0) + "oz";
  }





