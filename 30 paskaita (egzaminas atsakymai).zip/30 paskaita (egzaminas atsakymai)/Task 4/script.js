/* ------------------------------ TASK 4 -----------------------------------
Parašykite JS kodą, vartotjui atėjus į tinkaį kreipsis į cars.json failą
ir iš atvaizduos visus automobilių gamintojus ir pagamintus modelius. 
Kiekvienas gamintojas turės savo atvaizdavimo "kortelę", kurioje bus 
nurodomas gamintojas ir jo pagaminti modeliai.


Pastaba: Informacija apie automobilį (brand) (jo kortelė) bei turi turėti 
bent minimalų stilių;
-------------------------------------------------------------------------- */

const ENDPOINT = "cars.json";

const output = document.getElementById("output");

fetch(ENDPOINT)
  .then((response) => response.json())
  .then((data) => {
    const cards = createCardsWithCarInfo(data);
    cards.forEach((card) => output.appendChild(card));
    output.style.display = "flex";
    output.style.justifyContent = "space-between";
    output.style.maxWidth = "100%";
    output.style.flexWrap = "wrap";
    output.style.background = "#fefad4";
    output.style.justifyContent = "center";
  });

const createCardsWithCarInfo = (data) =>
  data.map((car) => createCard(car.brand, car.models));

const createCard = (carBrand, carModels) => {
  const card = document.createElement("div");
  card.style.border = "1px solid black";
  card.style.padding = "20px";
  card.style.width = "30vh";
  card.style.marginBottom = "20px";
  card.style.background = "#fcd0ba";
  card.style.marginRight = "30px";
  card.appendChild(getCarBrand(carBrand));
  card.appendChild(getCarModelsList(carModels));
  return card;
};

const getCarBrand = (data) => {
  const h1 = document.createElement("h1");
  h1.style.marginTop = 0;
  h1.style.textAlign = "center";
  h1.textContent = data;
  return h1;
};

const getCarModelsList = (data) => {
  const ul = document.createElement("ul");

  data.forEach((item) => {
    const li = document.createElement("li");
    li.textContent = item;
    li.style.listStyleType = "none";
    li.style.fontStyle = "italic";
    ul.appendChild(li);
  });
  return ul;
};
