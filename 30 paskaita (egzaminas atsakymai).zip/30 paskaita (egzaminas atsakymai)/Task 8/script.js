/* ------------------------------ TASK 8 --------------------------------------------
Sukurkite konstruktoriaus funkciją "Calculator" (naudokite ES5), kuri sukuria objektus su 3 metodais:
sum() - priima du skaičius ir grąžina jų sumą.
subtraction() - priima du skaičius ir grąžina jų skirtumą.
multiplication() - priima du skaičius ir grąžina jų daugybos rezultatą;
division() - priima du skaičius ir grąžina jų dalybos rezultatą;
------------------------------------------------------------------------------------ */
const num1 = 6;
const num2 = 3;

function Calculator() {
  this.sum = (arg1, arg2) => arg1 + arg2;
  this.subtraction = (arg1, arg2) => arg1 - arg2;
  this.multiplication = (arg1, arg2) => arg1 * arg2;
  this.division = (arg1, arg2) => arg1 / arg2;
}

const calc = new Calculator();
console.log(calc.sum(num1, num2));
console.log(calc.subtraction(num1, num2));
console.log(calc.multiplication(num1, num2));
console.log(calc.division(num1, num2));
